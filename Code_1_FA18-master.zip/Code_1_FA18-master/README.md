### Code_1_FA18

#### PUDT 2110 C, CRN 3781 
#### 2 West 13th St., Room 402
#### Thursdays 12:10-2:50 PM, Fall 2018
#### Bryan Ma

This course is an introduction to programming, the historical and cultural context of software in art and design, and the applications of “creative code” in a studio environment. Students will learn the fundamentals of all software development using the open source framework Processing, writing programs that generate computational visuals and facilitate interactive experiences.

[Syllabus](https://docs.google.com/document/d/1GGmO4fg71Lo3sdzieExb5xJIGwG-su6duaiHTuLBDY4/edit?usp=sharing)

